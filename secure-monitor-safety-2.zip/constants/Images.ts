export const IMAGES = {
  guardianHero: 'https://d64gsuwffb70l.cloudfront.net/68ef10432a2f45b76d69210f_1760497788680_218a26ee.webp',
  familyLinkHero: 'https://d64gsuwffb70l.cloudfront.net/68ef10432a2f45b76d69210f_1760497789473_f77edbad.webp',
  childAvatars: [
    'https://d64gsuwffb70l.cloudfront.net/68ef10432a2f45b76d69210f_1760497790472_227472b3.webp',
    'https://d64gsuwffb70l.cloudfront.net/68ef10432a2f45b76d69210f_1760497792920_5391f0e6.webp',
    'https://d64gsuwffb70l.cloudfront.net/68ef10432a2f45b76d69210f_1760497794909_4984b124.webp',
    'https://d64gsuwffb70l.cloudfront.net/68ef10432a2f45b76d69210f_1760497796625_0c0f405f.webp',
  ],
  mapMarker: 'https://d64gsuwffb70l.cloudfront.net/68ef10432a2f45b76d69210f_1760497797328_328231cc.webp',
  sosButton: 'https://d64gsuwffb70l.cloudfront.net/68ef10432a2f45b76d69210f_1760497798061_411882c1.webp',
  geofence: 'https://d64gsuwffb70l.cloudfront.net/68ef10432a2f45b76d69210f_1760497798862_ba0e99e6.webp',
};
